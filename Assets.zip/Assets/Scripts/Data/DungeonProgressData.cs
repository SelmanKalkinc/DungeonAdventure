[System.Serializable]
public class ProgressData
{
    public int highestCompletedDungeon = 0; // Default to zero (no dungeons completed)
}
