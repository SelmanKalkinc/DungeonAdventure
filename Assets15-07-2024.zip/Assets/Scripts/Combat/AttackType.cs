public enum AttackType
{
    Melee,
    Ranged
}
