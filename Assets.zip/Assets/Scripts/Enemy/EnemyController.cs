using UnityEngine;

public class EnemyController : MonoBehaviour
{
    // This class can handle high-level enemy control logic if needed.
    // Currently, individual components handle their own behavior.
}
