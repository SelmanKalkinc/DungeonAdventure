using UnityEngine;

public class Dungeon : MonoBehaviour
{
    // Dungeon-specific logic here
}
