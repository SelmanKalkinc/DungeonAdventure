using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class SerializableDictionary<TKey, TValue> : ISerializationCallbackReceiver
{
    [SerializeField]
    private List<TKey> keys = new List<TKey>();

    [SerializeField]
    private List<TValue> values = new List<TValue>();

    private Dictionary<TKey, TValue> target;
    public Dictionary<TKey, TValue> ToDictionary() { return target; }

    public SerializableDictionary(Dictionary<TKey, TValue> target)
    {
        this.target = target;
    }

    public SerializableDictionary()
    {
        this.target = new Dictionary<TKey, TValue>();
    }

    public void OnBeforeSerialize()
    {
        keys.Clear();
        values.Clear();
        foreach (var pair in target)
        {
            keys.Add(pair.Key);
            values.Add(pair.Value);
        }
    }

    public void OnAfterDeserialize()
    {
        target = new Dictionary<TKey, TValue>();

        for (int i = 0; i != Math.Min(keys.Count, values.Count); i++)
            target.Add(keys[i], values[i]);
    }
}